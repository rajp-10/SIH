import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import {
  Landmark,
  ArrowRight,
  Workflow,
  ShieldCheck,
  FileText,
  CalendarClock,
  ClipboardCheck,
  History,
  BarChart3,
  CheckCircle2,
  LockKeyhole,
  ExternalLink,
  ChevronRight,
  UserCheck,
  FileCheck2,
  Building2,
  Scale
} from 'lucide-react';
import { useStore } from '../context/Store';
import { DEMO_USERS } from '../data/auth';
import { formatMoney } from '../utils/logic';
import type { Role } from '../types';

export function LandingPage() {
  const navigate = useNavigate();
  const store = useStore();
  const [activeStage, setActiveStage] = useState(0);

  const stages = [
    {
      step: 1,
      title: 'FDR Submission',
      role: 'Institution User',
      department: 'Institutional Registrar / Finance Office',
      summary: 'Institution registers fixed deposit receipt details and attaches supporting document metadata.',
      detail: 'Joint lien details, principal amount, bank confirmation advice, and institutional reference codes are captured into a structured digital record for compliance vetting.'
    },
    {
      step: 2,
      title: 'Review & Scrutiny',
      role: 'AICTE Reviewing Official',
      department: 'Bureau of Scrutiny & Regulatory Verification',
      summary: 'Officials examine financial fields, verify document metadata, and perform consistency checks.',
      detail: 'System rules check for duplicate FDR numbers, tenure validity, and joint lien clauses. Reviewers record observations, flag discrepancies with mandatory reasons, or return records for correction.'
    },
    {
      step: 3,
      title: 'Independent Verification',
      role: 'Authorized Verification Cell',
      department: 'Designated Regulatory Verification Desk',
      summary: 'Administrative verification sign-off distinguishing human review from external banking confirmation.',
      detail: 'Records marked "Verified by Authorized Reviewer" progress to Active lifecycle monitoring with full audit event stamping. External bank confirmation remains an explicit manual or API workflow stage.'
    },
    {
      step: 4,
      title: 'Maturity & Renewal Tracking',
      role: 'Automated Regulatory Monitoring',
      department: 'Automated Compliance Engine',
      summary: 'Maturity dates are tracked dynamically with configurable thresholds (90, 60, 30, 7 days).',
      detail: 'Institutions receive automated notifications and can initiate non-destructive renewal or replacement flows that preserve historical instrument lineage and audit history.'
    },
    {
      step: 5,
      title: 'Release & Refund Approval',
      role: 'Approving Authority',
      department: 'Directorate of Approvals & Financial Sanctions',
      summary: 'Separation of duties ensures release requests are reviewed independently before financial authority sign-off.',
      detail: 'Institution users cannot approve their own release. Approving authorities review scrutiny findings and must provide written decision reasons for every approval or rejection.'
    }
  ];

  const totalPortfolioAmount = store.instruments.reduce((sum, i) => sum + i.amount, 0);
  const pendingScrutinyCount = store.instruments.filter(i =>
    ['Pending', 'Under Review', 'Correction Required'].includes(i.verification)
  ).length;

  const handleRoleSignIn = (role: Role) => {
    const user = DEMO_USERS.find(u => u.role === role) || store.users.find(u => u.role === role);
    if (user && user.email) {
      store.login(user.email, user.password || 'SecurityDeposit@2026', user);
      navigate('/app/dashboard');
    } else {
      navigate('/signin');
    }
  };

  const scrollToSection = (e: React.MouseEvent<HTMLAnchorElement>, id: string) => {
    e.preventDefault();
    const elem = document.getElementById(id);
    if (elem) {
      elem.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', background: 'var(--color-background)', color: 'var(--color-text)' }}>
      {/* Top Public Navigation */}
      <nav
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '16px 32px',
          background: 'var(--color-surface)',
          borderBottom: '1px solid var(--color-border)',
          position: 'sticky',
          top: 0,
          zIndex: 100
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <div
            style={{
              width: '38px',
              height: '38px',
              borderRadius: 'var(--radius-sm)',
              background: 'var(--color-primary)',
              color: 'var(--color-surface)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}
          >
            <Landmark size={20} />
          </div>
          <div>
            <span style={{ fontWeight: 700, fontSize: '17px', color: 'var(--color-primary)', display: 'block', lineHeight: 1.2 }}>
              FDR Guardian
            </span>
            <span style={{ fontSize: '11px', color: 'var(--color-text-muted)' }}>
              Institutional FDR Lifecycle Platform
            </span>
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '24px' }}>
          <div style={{ display: 'flex', gap: '20px', fontSize: 'var(--text-sm)', fontWeight: 500 }}>
            <a href="#overview" onClick={e => scrollToSection(e, 'overview')} style={{ color: 'var(--color-text)', textDecoration: 'none' }}>
              Overview
            </a>
            <a href="#lifecycle" onClick={e => scrollToSection(e, 'lifecycle')} style={{ color: 'var(--color-text)', textDecoration: 'none' }}>
              Workflow
            </a>
            <a href="#capabilities" onClick={e => scrollToSection(e, 'capabilities')} style={{ color: 'var(--color-text)', textDecoration: 'none' }}>
              Capabilities
            </a>
            <a href="#roles" onClick={e => scrollToSection(e, 'roles')} style={{ color: 'var(--color-text)', textDecoration: 'none' }}>
              Roles & RBAC
            </a>
            <a href="#governance" onClick={e => scrollToSection(e, 'governance')} style={{ color: 'var(--color-text)', textDecoration: 'none' }}>
              Governance
            </a>
          </div>

          <button
            type="button"
            className="btn btn-primary btn-small"
            onClick={() => navigate('/signin')}
            style={{ display: 'flex', alignItems: 'center', gap: '6px' }}
          >
            Sign In <ArrowRight size={14} />
          </button>
        </div>
      </nav>

      {/* Clean Hero Section — Completely uncluttered background, zero diagonal lines */}
      <section
        id="overview"
        style={{
          position: 'relative',
          background: 'var(--color-surface)',
          borderBottom: '1px solid var(--color-border)',
          padding: '64px 32px 72px'
        }}
      >
        <div
          style={{
            maxWidth: '1200px',
            margin: '0 auto',
            display: 'grid',
            gridTemplateColumns: '1.15fr 1fr',
            gap: '56px',
            alignItems: 'center'
          }}
        >
          {/* Left Column */}
          <div>
            <div
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '8px',
                background: 'var(--color-surface-subtle)',
                color: 'var(--color-primary)',
                padding: '6px 14px',
                borderRadius: 'var(--radius-full)',
                fontSize: 'var(--text-xs)',
                fontWeight: 600,
                marginBottom: '20px',
                border: '1px solid var(--color-border)'
              }}
            >
              <ShieldCheck size={14} />
              <span>FDR Lifecycle Management</span>
            </div>

            <h1
              style={{
                fontSize: 'clamp(30px, 3.4vw, 44px)',
                fontWeight: 800,
                lineHeight: 1.16,
                color: 'var(--color-primary)',
                margin: '0 0 18px',
                letterSpacing: '-0.02em'
              }}
            >
              Fixed Deposit Records, Managed with Transparency and Accountability.
            </h1>

            <p
              style={{
                fontSize: 'var(--text-base)',
                lineHeight: 1.6,
                color: 'var(--color-text-muted)',
                margin: '0 0 32px',
                maxWidth: '560px'
              }}
            >
              A centralized platform governing institutional fixed deposit receipts throughout their regulatory lifespan—from initial submission and reviewer scrutiny to automated maturity tracking, linked renewals, and role-separated release approvals.
            </p>

            <div style={{ display: 'flex', gap: '14px', flexWrap: 'wrap', alignItems: 'center' }}>
              <button
                type="button"
                className="btn btn-primary"
                onClick={() => navigate('/signin')}
                style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '13px 24px', fontSize: 'var(--text-sm)' }}
              >
                Sign In <ArrowRight size={16} />
              </button>
              <a
                href="#lifecycle"
                onClick={e => scrollToSection(e, 'lifecycle')}
                className="btn btn-secondary"
                style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '13px 22px', fontSize: 'var(--text-sm)', textDecoration: 'none' }}
              >
                <Workflow size={16} /> Explore Workflow
              </a>
            </div>

            <div style={{ marginTop: '28px', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <span style={{ fontSize: 'var(--text-xs)', color: 'var(--color-text-muted)', lineHeight: 1.45 }}>
                Simulated institutional administration environment. No claims of direct external banking clearinghouse integration.
              </span>
            </div>
          </div>

          {/* Right Column: 5-Stage FDR Lifecycle Visualization */}
          <div
            style={{
              background: 'var(--color-background)',
              borderRadius: 'var(--radius-lg)',
              padding: '24px',
              border: '1px solid var(--color-border)',
              boxShadow: 'var(--shadow-sm)'
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <div>
                <span style={{ fontSize: '11px', fontWeight: 700, color: 'var(--color-secondary)', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
                  Regulatory Progression
                </span>
                <h3 style={{ margin: '2px 0 0', fontSize: 'var(--text-lg)', color: 'var(--color-primary)' }}>
                  5-Stage FDR Lifecycle
                </h3>
              </div>
              <div
                style={{
                  width: '32px',
                  height: '32px',
                  borderRadius: 'var(--radius-sm)',
                  background: 'var(--color-surface)',
                  border: '1px solid var(--color-border)',
                  color: 'var(--color-primary)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center'
                }}
              >
                <Workflow size={17} />
              </div>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              {stages.map((st, idx) => {
                const isActive = activeStage === idx;
                return (
                  <div
                    key={st.title}
                    onClick={() => setActiveStage(idx)}
                    style={{
                      padding: '12px 14px',
                      borderRadius: 'var(--radius-md)',
                      background: isActive ? 'var(--color-surface)' : 'var(--color-surface-subtle)',
                      border: `1px solid ${isActive ? 'var(--color-primary)' : 'var(--color-border-subtle)'}`,
                      cursor: 'pointer',
                      transition: 'var(--transition-fast)'
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                        <span
                          style={{
                            width: '24px',
                            height: '24px',
                            borderRadius: 'var(--radius-full)',
                            background: isActive ? 'var(--color-primary)' : 'var(--color-border)',
                            color: isActive ? '#FFFFFF' : 'var(--color-text)',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            fontSize: '11px',
                            fontWeight: 700
                          }}
                        >
                          {st.step}
                        </span>
                        <strong style={{ fontSize: 'var(--text-sm)', color: 'var(--color-text)' }}>
                          {st.title}
                        </strong>
                      </div>
                      <span
                        style={{
                          fontSize: '10px',
                          fontWeight: 600,
                          padding: '2px 8px',
                          borderRadius: 'var(--radius-xs)',
                          background: isActive ? 'var(--color-secondary)' : 'var(--color-border)',
                          color: isActive ? 'var(--color-primary)' : 'var(--color-text)'
                        }}
                      >
                        {st.role}
                      </span>
                    </div>

                    {isActive && (
                      <div style={{ margin: '10px 0 0 34px', fontSize: 'var(--text-xs)', color: 'var(--color-text-muted)', lineHeight: 1.5 }}>
                        <div style={{ fontWeight: 600, color: 'var(--color-primary)', marginBottom: '3px' }}>
                          Responsible: {st.department}
                        </div>
                        <p style={{ margin: '0 0 4px' }}>{st.summary}</p>
                        <p style={{ margin: 0, opacity: 0.9 }}>{st.detail}</p>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* Operational Overview & Portfolio Metrics */}
      <section id="lifecycle" style={{ padding: '52px 32px', background: 'var(--color-surface)', borderBottom: '1px solid var(--color-border)' }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: '28px', flexWrap: 'wrap', gap: '16px' }}>
            <div>
              <div className="eyebrow">Operational Metrics</div>
              <h2 style={{ margin: '4px 0 0', fontSize: 'var(--text-2xl)', color: 'var(--color-primary)' }}>
                Demonstration Portfolio Overview
              </h2>
            </div>
            <p style={{ margin: 0, fontSize: 'var(--text-sm)', color: 'var(--color-text-muted)', maxWidth: '480px' }}>
              Calculated dynamically from active institutional records and pending regulatory workflow requests.
            </p>
          </div>

          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))',
              gap: '16px'
            }}
          >
            <div className="open-metric">
              <strong style={{ fontSize: '28px', color: 'var(--color-primary)' }}>{store.instruments.length}</strong>
              <span>Security Instruments Tracked</span>
            </div>
            <div className="open-metric">
              <strong style={{ fontSize: '28px', color: 'var(--color-primary)' }}>{formatMoney(totalPortfolioAmount)}</strong>
              <span>Total Monitored Portfolio</span>
            </div>
            <div className="open-metric">
              <strong style={{ fontSize: '28px', color: 'var(--color-warning)' }}>{pendingScrutinyCount}</strong>
              <span>Pending Reviewer Scrutiny</span>
            </div>
            <div className="open-metric">
              <strong style={{ fontSize: '28px', color: 'var(--color-primary)' }}>{store.requests.length}</strong>
              <span>Active Workflow Requests</span>
            </div>
          </div>
        </div>
      </section>

      {/* Core Capabilities Section */}
      <section id="capabilities" style={{ padding: '64px 32px', background: 'var(--color-background)', borderBottom: '1px solid var(--color-border)' }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: '44px' }}>
            <div className="eyebrow" style={{ justifyContent: 'center' }}>Institutional Governance</div>
            <h2 style={{ fontSize: 'var(--text-2xl)', color: 'var(--color-primary)', margin: '6px 0 10px' }}>
              Built for Institutional Accountability
            </h2>
            <p style={{ color: 'var(--color-text-muted)', maxWidth: '620px', margin: '0 auto', fontSize: 'var(--text-sm)', lineHeight: 1.5 }}>
              Strict separation between institution submission, official scrutiny, and final financial sanctioning.
            </p>
          </div>

          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
              gap: '24px'
            }}
          >
            {[
              {
                icon: FileText,
                title: 'Centralized Instrument Repository',
                desc: 'Universal registry indexed across institution codes, banks, FDR numbers, and maturity dates with multi-field search and CSV export.'
              },
              {
                icon: ShieldCheck,
                title: 'Reviewer Scrutiny & Discrepancies',
                desc: 'Reviewing officials verify document metadata, record checklist findings, and return defective records for institutional correction.'
              },
              {
                icon: CalendarClock,
                title: 'Date-Derived Maturity Tracking',
                desc: 'Reminders and alerts are calculated from calendar maturity dates and configurable regulatory threshold rules (90, 60, 30, 7 days).'
              },
              {
                icon: ClipboardCheck,
                title: 'Guarded Release Workflow',
                desc: 'Strict segregation of duties ensures institution users cannot approve their own release. Approving authorities must log written justifications.'
              },
              {
                icon: History,
                title: 'Audit Trail & Transparency',
                desc: 'Timestamped records log actor persona, role, action, and mandatory reasons for every regulatory state transition.'
              },
              {
                icon: BarChart3,
                title: 'Executive Analytics & Reporting',
                desc: 'Data-driven visual summaries for verification queues, lifecycle states, and workflow request throughput with spreadsheet exports.'
              }
            ].map(c => {
              const Icon = c.icon;
              return (
                <div
                  key={c.title}
                  style={{
                    padding: '24px',
                    borderRadius: 'var(--radius-md)',
                    background: 'var(--color-surface)',
                    border: '1px solid var(--color-border)',
                    boxShadow: 'var(--shadow-xs)'
                  }}
                >
                  <div
                    style={{
                      width: '42px',
                      height: '42px',
                      borderRadius: 'var(--radius-sm)',
                      background: 'var(--color-surface-subtle)',
                      border: '1px solid var(--color-border-subtle)',
                      color: 'var(--color-primary)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      marginBottom: '16px'
                    }}
                  >
                    <Icon size={22} />
                  </div>
                  <h3 style={{ margin: '0 0 8px', fontSize: 'var(--text-md)', color: 'var(--color-primary)' }}>
                    {c.title}
                  </h3>
                  <p style={{ margin: 0, fontSize: 'var(--text-sm)', color: 'var(--color-text-muted)', lineHeight: 1.5 }}>
                    {c.desc}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Role and Responsibility Overview */}
      <section id="roles" style={{ padding: '64px 32px', background: 'var(--color-surface)', borderBottom: '1px solid var(--color-border)' }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: '40px' }}>
            <div className="eyebrow" style={{ justifyContent: 'center' }}>Role-Based Access Control</div>
            <h2 style={{ fontSize: 'var(--text-2xl)', color: 'var(--color-primary)', margin: '6px 0 10px' }}>
              Four Clear Operational Personas
            </h2>
            <p style={{ color: 'var(--color-text-muted)', maxWidth: '580px', margin: '0 auto', fontSize: 'var(--text-sm)' }}>
              Permissions are partitioned to preserve regulatory checks and balances across institutional finance and governance.
            </p>
          </div>

          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))',
              gap: '20px'
            }}
          >
            {[
              {
                role: 'Institution User' as Role,
                badge: 'Exclusive: Submit New FDR',
                title: 'Institution User',
                desc: 'Submits new FDRs, attaches document metadata, views own institutional records, and requests renewal or release. Cannot self-approve.',
                button: 'Sign In as Institution'
              },
              {
                role: 'AICTE Reviewing Official' as Role,
                badge: 'Official Scrutiny Queue',
                title: 'Reviewing Official',
                desc: 'Scrutinizes submitted fields, marks checklist items, records observations, and flags discrepancies. Cannot submit new FDRs or approve releases.',
                button: 'Sign In as Reviewer'
              },
              {
                role: 'Approving Authority' as Role,
                badge: 'Financial Release Authority',
                title: 'Approving Authority',
                desc: 'Sanctions eligible release requests with mandatory written justification. Cannot submit FDRs or bypass review stages.',
                button: 'Sign In as Approver'
              },
              {
                role: 'System Administrator' as Role,
                badge: 'Governance & Settings',
                title: 'System Administrator',
                desc: 'Oversees platform users, configures reminder thresholds, inspects system audit logs, and manages demo data without operational approval rights.',
                button: 'Sign In as Admin'
              }
            ].map(r => (
              <div
                key={r.role}
                style={{
                  padding: '24px',
                  borderRadius: 'var(--radius-lg)',
                  border: '1px solid var(--color-border)',
                  background: 'var(--color-background)',
                  display: 'flex',
                  flexDirection: 'column',
                  justifyContent: 'space-between'
                }}
              >
                <div>
                  <span
                    style={{
                      fontSize: '11px',
                      fontWeight: 600,
                      color: 'var(--color-primary)',
                      background: 'var(--color-secondary)',
                      padding: '2px 8px',
                      borderRadius: 'var(--radius-xs)',
                      display: 'inline-block',
                      marginBottom: '12px'
                    }}
                  >
                    {r.badge}
                  </span>
                  <h3 style={{ margin: '0 0 8px', fontSize: 'var(--text-lg)', color: 'var(--color-primary)' }}>
                    {r.title}
                  </h3>
                  <p style={{ margin: '0 0 20px', fontSize: 'var(--text-xs)', color: 'var(--color-text-muted)', lineHeight: 1.5 }}>
                    {r.desc}
                  </p>
                </div>
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={() => handleRoleSignIn(r.role)}
                  style={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }}
                >
                  {r.button} <ArrowRight size={14} />
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Security, Accountability and Governance */}
      <section id="governance" style={{ padding: '60px 32px', background: 'var(--color-background)' }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: '36px' }}>
            <div className="eyebrow" style={{ justifyContent: 'center' }}>Accountability Framework</div>
            <h2 style={{ fontSize: 'var(--text-2xl)', color: 'var(--color-primary)', margin: '6px 0 10px' }}>
              Security, Auditability & Integrity
            </h2>
            <p style={{ color: 'var(--color-text-muted)', maxWidth: '580px', margin: '0 auto', fontSize: 'var(--text-sm)' }}>
              Core architectural principles ensuring institutional deposits remain fully auditable and protected against unilateral actions.
            </p>
          </div>

          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
              gap: '20px'
            }}
          >
            <div style={{ padding: '24px', background: 'var(--color-surface)', border: '1px solid var(--color-border)', borderRadius: 'var(--radius-md)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '12px' }}>
                <Scale size={20} color="var(--color-primary)" />
                <h4 style={{ margin: 0, fontSize: 'var(--text-md)', color: 'var(--color-primary)' }}>Separation of Duties</h4>
              </div>
              <p style={{ margin: 0, fontSize: 'var(--text-sm)', color: 'var(--color-text-muted)', lineHeight: 1.5 }}>
                Maker-Checker-Approver boundaries prevent conflicts of interest. An institution user cannot approve their own release request, and reviewing officials cannot unilaterally release funds.
              </p>
            </div>

            <div style={{ padding: '24px', background: 'var(--color-surface)', border: '1px solid var(--color-border)', borderRadius: 'var(--radius-md)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '12px' }}>
                <FileCheck2 size={20} color="var(--color-primary)" />
                <h4 style={{ margin: 0, fontSize: 'var(--text-md)', color: 'var(--color-primary)' }}>Non-Destructive Lineage</h4>
              </div>
              <p style={{ margin: 0, fontSize: 'var(--text-sm)', color: 'var(--color-text-muted)', lineHeight: 1.5 }}>
                FDR renewals and replacements register new successor instruments while permanently preserving the predecessor instrument, its verification notes, and historical audit entries.
              </p>
            </div>

            <div style={{ padding: '24px', background: 'var(--color-surface)', border: '1px solid var(--color-border)', borderRadius: 'var(--radius-md)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '12px' }}>
                <LockKeyhole size={20} color="var(--color-primary)" />
                <h4 style={{ margin: 0, fontSize: 'var(--text-md)', color: 'var(--color-primary)' }}>Immutable Audit Stamping</h4>
              </div>
              <p style={{ margin: 0, fontSize: 'var(--text-sm)', color: 'var(--color-text-muted)', lineHeight: 1.5 }}>
                Every action records actor persona, role, timestamp, entity reference, and mandatory written justifications for critical decisions such as discrepancy flags and release decisions.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer
        style={{
          marginTop: 'auto',
          padding: '36px 32px',
          background: 'var(--color-primary)',
          color: 'var(--color-surface)',
          borderTop: '1px solid var(--color-primary-hover)'
        }}
      >
        <div
          style={{
            maxWidth: '1200px',
            margin: '0 auto',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            flexWrap: 'wrap',
            gap: '20px',
            fontSize: 'var(--text-xs)'
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <div
              style={{
                width: '32px',
                height: '32px',
                borderRadius: 'var(--radius-xs)',
                background: 'var(--color-secondary)',
                color: 'var(--color-primary)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}
            >
              <Landmark size={18} />
            </div>
            <div>
              <strong style={{ fontSize: 'var(--text-sm)', display: 'block' }}>FDR Guardian</strong>
              <span style={{ opacity: 0.8 }}>Institutional Fixed Deposit Receipt Lifecycle Platform</span>
            </div>
          </div>

          <div style={{ opacity: 0.85, maxWidth: '520px', lineHeight: 1.45 }}>
            Demonstration software for institutional security deposit lifecycle oversight. Fictional sample records. No direct live bank integration claimed.
          </div>

          <button
            type="button"
            className="btn btn-small"
            onClick={() => navigate('/signin')}
            style={{
              background: 'var(--color-secondary)',
              color: 'var(--color-primary)',
              fontWeight: 600,
              border: 'none',
              padding: '8px 16px'
            }}
          >
            Sign In to Platform
          </button>
        </div>
      </footer>
    </div>
  );
}

export default LandingPage;
